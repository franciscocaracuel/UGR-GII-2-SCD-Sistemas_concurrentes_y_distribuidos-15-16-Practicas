package monitor;

public interface RunnableWithResult<T> {
	public T run() ;
}
